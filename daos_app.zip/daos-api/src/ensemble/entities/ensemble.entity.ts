export class Ensemble {
  id: string;
  name: string;
  description: string;
}
