export class Post {}
