export class RegisterUserDto {
  name: string;
  email: string;
  password: string;
  location: string;
  passwordConfirmation: string;
}
