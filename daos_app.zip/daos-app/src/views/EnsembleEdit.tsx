import Layout from "../components/Layout";

export async function loader() {}
export async function action() {}

export default function EnsembleEdit({}) {
  return <Layout title="Edit Ensemble">Showing Ensemble edit</Layout>;
}
