import Layout from "../components/Layout";

export async function loader() {}
export async function action() {}

export default function ProfileEdit({}) {
  return <Layout title="Edit profile">Showing profile edit</Layout>;
}
